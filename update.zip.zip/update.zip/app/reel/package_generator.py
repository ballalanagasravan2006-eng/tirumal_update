import os
import re
import json
import datetime
from pathlib import Path
from app.database.db import get_connection
from app.assets.thumbnail_generator import generate_thumbnail
from app.assets.poster_generator import generate_poster
from app.ai.fact_extractor import extract_facts
from app.ai.script_generator import generate_reel_scripts

def slugify(text: str) -> str:
    cleaned = re.sub(r"[^\w\s-]", "", text.lower())
    return re.sub(r"[-\s]+", "-", cleaned).strip("-")[:40]

def create_reel_packages() -> dict:
    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("SELECT * FROM ttd_news WHERE processing_status IN ('NEW', 'PROCESSING', 'PROCESSED')")
    news_items = cursor.fetchall()

    packages_created = 0
    errors = 0

    for news in news_items:
        news_id = news["id"]
        title = news["title"]
        category = news["category"] or "TTD Announcements"
        source_url = news["source_url"]
        article_text = news["article_text"] or news["summary"] or title
        pub_date = news["published_date"] or datetime.date.today().isoformat()

        try:
            # Build slugified reel package path
            date_str = pub_date[:10] if len(pub_date) >= 10 else datetime.date.today().isoformat()
            slug = slugify(title) or f"news-{news_id}"
            pkg_folder_name = f"{date_str}-{slug}"
            pkg_dir = Path("data/reels") / pkg_folder_name
            pkg_dir.mkdir(parents=True, exist_ok=True)
            scripts_dir = pkg_dir / "scripts"
            scripts_dir.mkdir(parents=True, exist_ok=True)
            media_dir = pkg_dir / "media"
            media_dir.mkdir(parents=True, exist_ok=True)

            # 1. Save source.txt
            source_file = pkg_dir / "source.txt"
            with open(source_file, "w", encoding="utf-8") as f:
                f.write(f"SOURCE:\nOfficial TTD News\n\nURL:\n{source_url}\n\nCOLLECTED_AT:\n{news['collected_at']}\n")

            # 2. Save article.json
            article_file = pkg_dir / "article.json"
            article_data = {
                "id": news_id,
                "title": title,
                "title_te": news["title_te"],
                "category": category,
                "published_date": pub_date,
                "source_url": source_url,
                "article_text": article_text,
                "summary": news["summary"]
            }
            with open(article_file, "w", encoding="utf-8") as f:
                json.dump(article_data, f, indent=2, ensure_ascii=False)

            # 3. Generate Thumbnail & Poster Assets
            thumb_path = str(pkg_dir / "thumbnail.jpg")
            poster_path = str(pkg_dir / "poster.jpg")

            generate_thumbnail(news_id, title, category, thumb_path)
            generate_poster(news_id, title, category, poster_path)

            now_str = datetime.datetime.now(datetime.timezone.utc).isoformat()
            cursor.execute("INSERT OR REPLACE INTO reel_assets (id, news_id, asset_type, local_path, created_at) VALUES (?, ?, ?, ?, ?)",
                           (f"ast-thumb-{news_id}", news_id, "THUMBNAIL", thumb_path, now_str))
            cursor.execute("INSERT OR REPLACE INTO reel_assets (id, news_id, asset_type, local_path, created_at) VALUES (?, ?, ?, ?, ?)",
                           (f"ast-post-{news_id}", news_id, "POSTER", poster_path, now_str))

            # 4. Extract Facts & Generate Multilingual Scripts
            facts = extract_facts(title, article_text, source_url)
            scripts = generate_reel_scripts(title, article_text, facts, source_url)

            with open(scripts_dir / "telugu.txt", "w", encoding="utf-8") as f:
                f.write(scripts["telugu"])
            with open(scripts_dir / "hindi.txt", "w", encoding="utf-8") as f:
                f.write(scripts["hindi"])
            with open(scripts_dir / "english.txt", "w", encoding="utf-8") as f:
                f.write(scripts["english"])

            # 5. Media Telemetry
            cursor.execute("SELECT * FROM ttd_media WHERE news_id = ?", (news_id,))
            media_records = cursor.fetchall()
            video_found = any(m["media_type"] == "VIDEO" for m in media_records)
            video_record = next((m for m in media_records if m["media_type"] == "VIDEO"), None)

            # 6. Save metadata.json
            metadata_file = pkg_dir / "metadata.json"
            meta = {
                "news_id": news_id,
                "title": title,
                "published_date": pub_date,
                "category": category,
                "source": "Official TTD News",
                "source_url": source_url,
                "verification_status": news["verification_status"] or "OFFICIAL_PRIMARY_SOURCE",
                "media": {
                    "video": {
                        "found": video_found,
                        "source_url": video_record["source_url"] if video_record else None,
                        "downloaded": video_record["download_status"] == "DOWNLOADED" if video_record else False,
                        "rights_status": video_record["rights_status"] if video_record else "NO_VIDEO"
                    },
                    "images": [m["source_url"] for m in media_records if m["media_type"] == "IMAGE"]
                },
                "assets": {
                    "thumbnail": "thumbnail.jpg",
                    "poster": "poster.jpg",
                    "telugu_script": "scripts/telugu.txt",
                    "hindi_script": "scripts/hindi.txt",
                    "english_script": "scripts/english.txt"
                },
                "created_at": now_str
            }
            with open(metadata_file, "w", encoding="utf-8") as f:
                json.dump(meta, f, indent=2, ensure_ascii=False)

            # 7. Record in reel_packages table
            pkg_id = f"pkg-{news_id}"
            cursor.execute("""
            INSERT OR REPLACE INTO reel_packages (id, news_id, package_path, status, created_at, updated_at)
            VALUES (?, ?, ?, 'READY', ?, ?)
            """, (pkg_id, news_id, str(pkg_dir), now_str, now_str))

            # Update news item status to READY
            cursor.execute("UPDATE ttd_news SET processing_status = 'READY', updated_at = ? WHERE id = ?", (now_str, news_id))

            conn.commit()
            packages_created += 1

        except Exception as e:
            try:
                print(f"[Package] Error creating package for news {news_id}: {e}")
            except Exception:
                print(f"[Package] Error creating package for news {news_id}: {str(e).encode('ascii', 'ignore').decode('ascii')}")
            cursor.execute("UPDATE ttd_news SET processing_status = 'ERROR' WHERE id = ?", (news_id,))
            conn.commit()
            errors += 1

    conn.close()

    return {
        "packages_created": packages_created,
        "errors": errors
    }

if __name__ == "__main__":
    create_reel_packages()
