import sqlite3
import os
from pathlib import Path
from dotenv import load_dotenv

load_dotenv()

DB_PATH = os.getenv("DATABASE_PATH", "data/ttd_official_news_database.sqlite")

def get_connection():
    db_file = Path(DB_PATH)
    db_file.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(db_file))
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS ttd_news (
        id TEXT PRIMARY KEY,
        title TEXT NOT NULL,
        title_te TEXT,
        published_date TEXT,
        category TEXT,
        source_url TEXT UNIQUE NOT NULL,
        source TEXT DEFAULT 'Official TTD News',
        source_type TEXT DEFAULT 'OFFICIAL_PRIMARY_SOURCE',
        article_text TEXT,
        summary TEXT,
        raw_excerpt TEXT,
        verification_status TEXT DEFAULT 'VERIFIED',
        collected_at TEXT,
        content_hash TEXT,
        processing_status TEXT DEFAULT 'NEW',
        updated_at TEXT
    );
    """)

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS ttd_media (
        id TEXT PRIMARY KEY,
        news_id TEXT NOT NULL,
        media_type TEXT NOT NULL,
        source_url TEXT NOT NULL,
        local_path TEXT,
        mime_type TEXT,
        file_hash TEXT,
        source_type TEXT DEFAULT 'TTD_NEWS_IMAGE',
        rights_status TEXT DEFAULT 'CHECK_REQUIRED',
        download_status TEXT DEFAULT 'NOT_ATTEMPTED',
        created_at TEXT NOT NULL,
        FOREIGN KEY (news_id) REFERENCES ttd_news(id)
    );
    """)

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS reel_assets (
        id TEXT PRIMARY KEY,
        news_id TEXT NOT NULL,
        asset_type TEXT NOT NULL,
        local_path TEXT NOT NULL,
        source_media_id TEXT,
        language TEXT,
        metadata_json TEXT,
        created_at TEXT NOT NULL,
        FOREIGN KEY (news_id) REFERENCES ttd_news(id)
    );
    """)

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS reel_packages (
        id TEXT PRIMARY KEY,
        news_id TEXT NOT NULL,
        package_path TEXT NOT NULL,
        status TEXT DEFAULT 'READY',
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL,
        FOREIGN KEY (news_id) REFERENCES ttd_news(id)
    );
    """)

    conn.commit()
    conn.close()
    print(f"[DB] Initialized database schema at {DB_PATH}")

if __name__ == "__main__":
    init_db()
