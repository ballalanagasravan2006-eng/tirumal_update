from app.database.db import get_connection

def run_migrations():
    conn = get_connection()
    cursor = conn.cursor()
    
    # Safely alter table to add columns if schema was upgraded
    cursor.execute("PRAGMA table_info(ttd_news)")
    existing_cols = {row[1] for row in cursor.fetchall()}
    
    expected_cols = {
        "title_te": "TEXT",
        "raw_excerpt": "TEXT",
        "verification_status": "TEXT DEFAULT 'VERIFIED'",
        "collected_at": "TEXT",
        "content_hash": "TEXT",
        "processing_status": "TEXT DEFAULT 'NEW'",
        "updated_at": "TEXT"
    }

    for col, type_def in expected_cols.items():
        if col not in existing_cols:
            try:
                cursor.execute(f"ALTER TABLE ttd_news ADD COLUMN {col} {type_def}")
                print(f"[Migration] Added column {col} to ttd_news")
            except Exception as e:
                print(f"[Migration] Column {col} check error: {e}")

    conn.commit()
    conn.close()

if __name__ == "__main__":
    run_migrations()
