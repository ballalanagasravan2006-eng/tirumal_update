from dataclasses import dataclass
from typing import Optional

@dataclass
class TTDNewsItem:
    id: str
    title: str
    source_url: str
    title_te: Optional[str] = None
    published_date: Optional[str] = None
    category: Optional[str] = None
    source: str = "Official TTD News"
    source_type: str = "OFFICIAL_PRIMARY_SOURCE"
    article_text: Optional[str] = None
    summary: Optional[str] = None
    raw_excerpt: Optional[str] = None
    verification_status: str = "VERIFIED"
    collected_at: Optional[str] = None
    content_hash: Optional[str] = None
    processing_status: str = "NEW"
    updated_at: Optional[str] = None

@dataclass
class TTDMediaItem:
    id: str
    news_id: str
    media_type: str
    source_url: str
    created_at: str
    local_path: Optional[str] = None
    mime_type: Optional[str] = None
    file_hash: Optional[str] = None
    source_type: str = "TTD_NEWS_IMAGE"
    rights_status: str = "CHECK_REQUIRED"
    download_status: str = "NOT_ATTEMPTED"

@dataclass
class ReelAsset:
    id: str
    news_id: str
    asset_type: str
    local_path: str
    created_at: str
    source_media_id: Optional[str] = None
    language: Optional[str] = None
    metadata_json: Optional[str] = None

@dataclass
class ReelPackageRecord:
    id: str
    news_id: str
    package_path: str
    created_at: str
    updated_at: str
    status: str = "READY"
