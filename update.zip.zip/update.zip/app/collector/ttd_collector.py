import re
import time
import requests
import datetime
from bs4 import BeautifulSoup
from urllib.parse import urljoin
from app.database.db import get_connection
from app.collector.parser import parse_ttd_article
from app.collector.dedup import is_duplicate_article

BASE_URL = "https://news.tirumala.org/"
HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
}

def discover_article_urls(max_pages=1):
    discovered = set()
    for page in range(1, max_pages + 1):
        url = BASE_URL if page == 1 else f"{BASE_URL}page/{page}/"
        try:
            res = requests.get(url, headers=HEADERS, timeout=12)
            if res.status_code != 200:
                continue
            soup = BeautifulSoup(res.text, "html.parser")
            for a in soup.find_all("a", href=True):
                href = a["href"]
                # Match TTD news article URL pattern
                if "news.tirumala.org" in href and not any(x in href for x in ["/category/", "/page/", "/tag/", "/wp-content/", "xmlrpc.php", "#"]):
                    if len(href.replace(BASE_URL, "").strip("/").split("/")) == 1 and len(href) > len(BASE_URL) + 5:
                        discovered.add(href)
        except Exception as e:
            print(f"[Collector] Error fetching index page {url}: {e}")
    return list(discovered)

def collect_ttd_news(max_articles=5) -> dict:
    from app.database.db import init_db
    from app.database.migrations import run_migrations
    init_db()
    run_migrations()

    print("TTD NEWS COLLECTOR")
    print("------------------")
    print("Checking official TTD News (https://news.tirumala.org/)...")

    article_urls = discover_article_urls(max_pages=2)
    discovered_count = len(article_urls)
    new_count = 0
    existing_count = 0
    failed_count = 0

    conn = get_connection()
    cursor = conn.cursor()

    for url in article_urls[:max_articles]:
        try:
            # Check deduplication first
            cursor.execute("SELECT id FROM ttd_news WHERE source_url = ?", (url,))
            if cursor.fetchone():
                existing_count += 1
                continue

            time.sleep(1) # Respectful request rate limit
            res = requests.get(url, headers=HEADERS, timeout=12)
            if res.status_code != 200:
                failed_count += 1
                continue

            parsed = parse_ttd_article(url, res.text)
            
            if is_duplicate_article(url, parsed["content_hash"]):
                existing_count += 1
                continue

            now_str = datetime.datetime.now(datetime.timezone.utc).isoformat()
            news_id = f"ttd-{int(time.time()*1000)}"

            cursor.execute("""
            INSERT INTO ttd_news (
                id, title, title_te, published_date, category, source_url, source,
                source_type, article_text, summary, raw_excerpt, verification_status,
                collected_at, content_hash, processing_status, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                news_id,
                parsed["title"],
                parsed["title_te"],
                parsed["published_date"] or now_str,
                parsed["category"],
                url,
                "Official TTD News",
                "OFFICIAL_PRIMARY_SOURCE",
                parsed["article_text"],
                parsed["raw_excerpt"],
                parsed["raw_excerpt"],
                "VERIFIED",
                now_str,
                parsed["content_hash"],
                "NEW",
                now_str
            ))

            # Store discovered media records
            for img_url in parsed["images"]:
                media_id = f"med-{int(time.time()*1000)}-{hash(img_url) % 10000}"
                cursor.execute("""
                INSERT OR IGNORE INTO ttd_media (
                    id, news_id, media_type, source_url, created_at, rights_status, download_status
                ) VALUES (?, ?, ?, ?, ?, ?, ?)
                """, (media_id, news_id, "IMAGE", img_url, now_str, "CHECK_REQUIRED", "NOT_ATTEMPTED"))

            for vid_url in parsed["videos"]:
                media_id = f"med-{int(time.time()*1000)}-{hash(vid_url) % 10000}"
                cursor.execute("""
                INSERT OR IGNORE INTO ttd_media (
                    id, news_id, media_type, source_url, created_at, rights_status, download_status
                ) VALUES (?, ?, ?, ?, ?, ?, ?)
                """, (media_id, news_id, "VIDEO", vid_url, now_str, "CHECK_REQUIRED", "NOT_ATTEMPTED"))

            conn.commit()
            new_count += 1

        except Exception as e:
            print(f"[Collector] Error processing article {url}: {e}")
            failed_count += 1

    conn.close()

    print(f"\nArticles discovered: {discovered_count}")
    print(f"New articles       : {new_count}")
    print(f"Existing articles  : {existing_count}")
    print(f"Failed             : {failed_count}")
    print("\nDatabase updated successfully.")

    return {
        "discovered": discovered_count,
        "new": new_count,
        "existing": existing_count,
        "failed": failed_count
    }

if __name__ == "__main__":
    collect_ttd_news()
