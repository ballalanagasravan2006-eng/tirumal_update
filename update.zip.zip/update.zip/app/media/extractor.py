import datetime
from app.database.db import get_connection

def extract_media_for_unprocessed_news() -> dict:
    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("SELECT * FROM ttd_news WHERE processing_status IN ('NEW', 'PROCESSING')")
    news_items = cursor.fetchall()

    extracted_count = 0
    images_found = 0
    videos_found = 0

    for news in news_items:
        news_id = news["id"]
        cursor.execute("SELECT * FROM ttd_media WHERE news_id = ?", (news_id,))
        media_records = cursor.fetchall()

        for m in media_records:
            if m["media_type"] == "IMAGE":
                images_found += 1
            elif m["media_type"] == "VIDEO":
                videos_found += 1

        extracted_count += 1

    conn.close()

    return {
        "items_processed": extracted_count,
        "images_found": images_found,
        "videos_found": videos_found
    }
