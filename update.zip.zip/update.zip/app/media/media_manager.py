from app.media.extractor import extract_media_for_unprocessed_news
from app.media.downloader import process_media_downloads

def run_media_pipeline():
    extract_stats = extract_media_for_unprocessed_news()
    download_stats = process_media_downloads()
    return {
        "extracted": extract_stats,
        "download": download_stats
    }
