import os
import requests
import hashlib
from pathlib import Path
from app.database.db import get_connection

def process_media_downloads() -> dict:
    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("SELECT * FROM ttd_media WHERE download_status = 'NOT_ATTEMPTED'")
    pending_media = cursor.fetchall()

    downloaded = 0
    skipped = 0
    failed = 0

    for m in pending_media:
        media_id = m["id"]
        source_url = m["source_url"]
        rights = m["rights_status"]

        # Rule 10: Only download if explicitly PERMITTED, LICENSED, or USER_OWNED
        if rights not in ["PERMITTED", "LICENSED", "USER_OWNED"]:
            cursor.execute(
                "UPDATE ttd_media SET download_status = 'SKIPPED' WHERE id = ?",
                (media_id,)
            )
            skipped += 1
            continue

        try:
            res = requests.get(source_url, timeout=15, stream=True)
            if res.status_code == 200:
                ext = ".jpg" if m["media_type"] == "IMAGE" else ".mp4"
                target_dir = Path("data/media/images") if m["media_type"] == "IMAGE" else Path("data/media/videos")
                target_dir.mkdir(parents=True, exist_ok=True)
                
                filename = f"{media_id}{ext}"
                local_path = str(target_dir / filename)
                
                hasher = hashlib.sha256()
                with open(local_path, "wb") as f:
                    for chunk in res.iter_content(chunk_size=8192):
                        f.write(chunk)
                        hasher.update(chunk)

                file_hash = hasher.hexdigest()
                cursor.execute("""
                UPDATE ttd_media SET local_path = ?, file_hash = ?, download_status = 'DOWNLOADED' WHERE id = ?
                """, (local_path, file_hash, media_id))
                downloaded += 1
            else:
                cursor.execute("UPDATE ttd_media SET download_status = 'FAILED' WHERE id = ?", (media_id,))
                failed += 1
        except Exception as e:
            print(f"[Downloader] Error downloading {source_url}: {e}")
            cursor.execute("UPDATE ttd_media SET download_status = 'FAILED' WHERE id = ?", (media_id,))
            failed += 1

    conn.commit()
    conn.close()

    return {
        "downloaded": downloaded,
        "skipped": skipped,
        "failed": failed
    }
